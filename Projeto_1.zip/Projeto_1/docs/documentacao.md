# Projeto Avaliativo 1 - Refatoração de Código Estruturado para Programação Orientada a Objetos

## Objetivo
Refatorar um código estruturado simples para o paradigma da Programação Orientada a Objetos (POO), utilizando uma classe `Cliente`.

## Estrutura do Projeto

 `src/`: contém a implementação da classe Cliente (`Cliente.h` e `Cliente.cpp`)
 `test/`: contém o arquivo de teste que instancia objetos e verifica o funcionamento da classe
 `docs/`: contém esta documentação

## Descrição da Classe

A classe `Cliente` possui os atributos:
 `nome` (string)
 `idade` (int)
 `saldo` (float)

E os métodos:
 `mostrar_informacoes()`: exibe as informações do cliente
 `atualizar_saldo(valor)`: altera o saldo do cliente

## Execução

Para compilar o projeto:

```bash
g++ test/teste.cpp src/Cliente.cpp -o cliente
./cliente
```
