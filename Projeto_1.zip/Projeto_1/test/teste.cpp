#include "../src/Cliente.h"

int main() {
    Cliente cliente1("João Silva", 30, 1000.0f);

    cliente1.mostrar_informacoes();

    cliente1.atualizar_saldo(500.0f);

    cliente1.mostrar_informacoes();

    return 0;
}
