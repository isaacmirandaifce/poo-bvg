#include "Cliente.h"
#include <iostream>

Cliente::Cliente(std::string nome, int idade, float saldo)
    : nome(nome), idade(idade), saldo(saldo) {}

void Cliente::mostrar_informacoes() const {
    std::cout << "Cliente: " << nome
              << ", Idade: " << idade
              << ", Saldo: R$ " << saldo << std::endl;
}

void Cliente::atualizar_saldo(float valor) {
    saldo += valor;
}
