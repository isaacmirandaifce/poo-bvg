#ifndef CLIENTE_H
#define CLIENTE_H

#include <string>

class Cliente {
private:
    std::string nome;
    int idade;
    float saldo;

public:
    Cliente(std::string nome, int idade, float saldo);

    void mostrar_informacoes() const;
    void atualizar_saldo(float valor);
};

#endif
